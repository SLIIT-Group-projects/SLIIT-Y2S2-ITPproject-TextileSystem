import React from 'react';

const Footer = () => {
  return (
    <div>
      <p>&copy; 2024 PTI TEXTILES </p>
    </div>
  );
};

export default Footer;